
-- --------------------------------------------------------

--
-- Table structure for table `tt_computer`
--

CREATE TABLE `tt_computer` (
  `id` int(11) NOT NULL,
  `user` varchar(50) NOT NULL,
  `IP` varchar(15) NOT NULL,
  `HeDieuHanh` varchar(50) DEFAULT NULL,
  `VaiTro` varchar(50) DEFAULT NULL,
  `Time_conn` datetime DEFAULT current_timestamp(),
  `status` varchar(10) DEFAULT NULL,
  `in4_Ram` varchar(20) DEFAULT NULL,
  `in4_Rom` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tt_computer`
--

INSERT INTO `tt_computer` (`id`, `user`, `IP`, `HeDieuHanh`, `VaiTro`, `Time_conn`, `status`, `in4_Ram`, `in4_Rom`) VALUES
(28, 'VT', '192.168.1.2', 'Windows', 'QuanTri', '2024-04-07 15:30:46', 'Online ✅️', '16', '512');
