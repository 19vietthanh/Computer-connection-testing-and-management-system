package test.constants;

public interface IConstants {
	
	public final static String XML_FILE = "nmap-xml/enchantedgrounds-08272010-2140.xml" ;

}
